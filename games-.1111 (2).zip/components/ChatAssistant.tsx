
// Component removed - No AI features requested
export default function ChatAssistant() { return null; }
