
import React from 'react';
import { Game } from '../types';
import { X, Maximize2, RotateCcw, ThumbsUp, Info } from 'lucide-react';

interface GameRoomProps {
  game: Game;
  onClose: () => void;
}

const GameRoom: React.FC<GameRoomProps> = ({ game, onClose }) => {
  const toggleFullscreen = () => {
    const frame = document.getElementById('game-frame');
    if (frame?.requestFullscreen) frame.requestFullscreen();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950 flex flex-col">
      <div className="h-16 bg-slate-900/80 backdrop-blur-md border-b border-slate-800 flex items-center justify-between px-6 shrink-0">
        <div className="flex items-center gap-4">
          <button 
            onClick={onClose}
            className="p-2 hover:bg-slate-800 rounded-xl text-slate-400 hover:text-white transition-all"
          >
            <X className="w-6 h-6" />
          </button>
          <div>
            <h1 className="text-base md:text-xl font-orbitron font-bold text-white tracking-tight">
              {game.title}
            </h1>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button className="flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-bold transition-all">
            <ThumbsUp className="w-4 h-4" />
            Like
          </button>
          <div className="w-px h-6 bg-slate-800 mx-2" />
          <button 
            onClick={() => {
              const frame = document.getElementById('game-frame') as HTMLIFrameElement;
              if (frame) frame.src = frame.src;
            }}
            className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg"
            title="Reload Game"
          >
            <RotateCcw className="w-5 h-5" />
          </button>
          <button 
            onClick={toggleFullscreen}
            className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg"
            title="Fullscreen"
          >
            <Maximize2 className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div className="flex-1 bg-black relative flex items-center justify-center overflow-hidden">
        <iframe 
          id="game-frame"
          src={game.url}
          className="w-full h-full border-none shadow-2xl"
          title={game.title}
          allowFullScreen
          allow="autoplay; fullscreen; keyboard"
        />
        
        <div className="hidden xl:flex absolute right-6 top-6 w-72 flex-col gap-4">
          <div className="bg-slate-900/60 backdrop-blur-xl border border-slate-800/50 p-6 rounded-2xl shadow-2xl">
            <div className="flex items-center gap-2 mb-3 text-indigo-400">
              <Info className="w-4 h-4" />
              <h2 className="text-sm font-bold uppercase tracking-widest">Controls</h2>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Standard keys usually apply: Arrows/WASD for movement, Space to action. Use the buttons above for full-screen.
            </p>
          </div>
          
          <div className="bg-indigo-600/10 backdrop-blur-xl border border-indigo-500/20 p-6 rounded-2xl">
            <div className="flex justify-between text-[10px] font-bold uppercase tracking-widest text-indigo-300 mb-2">
              <span>Category</span>
              <span>{game.category}</span>
            </div>
            <div className="flex justify-between text-[10px] font-bold uppercase tracking-widest text-indigo-300">
              <span>Community Rating</span>
              <span>⭐ {game.rating}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default GameRoom;
