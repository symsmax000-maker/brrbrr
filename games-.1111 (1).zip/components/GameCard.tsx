
import React from 'react';
import { Game } from '../types';
import { Play, Star, Users } from 'lucide-react';

interface GameCardProps {
  game: Game;
  onSelect: (game: Game) => void;
}

const GameCard: React.FC<GameCardProps> = ({ game, onSelect }) => {
  return (
    <div 
      onClick={() => onSelect(game)}
      className="group relative bg-slate-900/40 rounded-2xl overflow-hidden border border-slate-800/60 hover:border-indigo-500/50 transition-all duration-500 cursor-pointer hover:-translate-y-2 shadow-2xl"
    >
      <div className="relative aspect-[16/10] overflow-hidden">
        <img 
          src={game.thumbnail} 
          alt={game.title}
          loading="lazy"
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 ease-out"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent opacity-90 group-hover:opacity-60 transition-opacity" />
        
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-500">
          <div className="bg-indigo-600 p-4 rounded-full shadow-2xl transform translate-y-4 group-hover:translate-y-0 transition-all duration-500">
            <Play className="w-8 h-8 fill-white text-white" />
          </div>
        </div>

        <div className="absolute top-4 left-4 px-3 py-1 bg-black/60 backdrop-blur-md rounded-full text-[10px] font-black uppercase tracking-widest text-indigo-300 border border-white/10">
          {game.category}
        </div>
      </div>

      <div className="p-5">
        <h3 className="text-lg font-orbitron font-bold text-white mb-2 group-hover:text-indigo-400 transition-colors">
          {game.title}
        </h3>
        <p className="text-slate-400 text-xs line-clamp-2 mb-4 leading-relaxed">
          {game.description}
        </p>
        
        <div className="flex items-center justify-between pt-4 border-t border-slate-800/40">
          <div className="flex items-center gap-1 text-yellow-500">
            <Star className="w-3 h-3 fill-current" />
            <span className="text-[11px] font-bold">{game.rating}</span>
          </div>
          <div className="flex items-center gap-1 text-slate-500">
            <Users className="w-3 h-3" />
            <span className="text-[11px] font-bold">{game.plays}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default GameCard;
