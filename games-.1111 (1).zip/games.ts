
import { Game, GameCategory } from './types';

export const GAMES_DATA: Game[] = [
  {
    id: "1",
    title: "Hextris",
    description: "A fast-paced puzzle game inspired by Tetris. Rotate the hexagon to match colors.",
    thumbnail: "https://images.unsplash.com/photo-1614850523296-d8c1af93d400?w=800&q=80",
    url: "https://hextris.io/",
    category: GameCategory.PUZZLE,
    rating: 4.8,
    plays: "2.5M"
  },
  {
    id: "2",
    title: "2048",
    description: "The viral number-sliding challenge. Can you reach the 2048 tile?",
    thumbnail: "https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=800&q=80",
    url: "https://play2048.co/",
    category: GameCategory.PUZZLE,
    rating: 4.9,
    plays: "10M+"
  },
  {
    id: "3",
    title: "Pac-Man Classic",
    description: "The 80s legend. Eat pellets, avoid ghosts, and clear the maze.",
    thumbnail: "https://images.unsplash.com/photo-1552820728-8b83bb6b773f?w=800&q=80",
    url: "https://www.google.com/logos/2010/pacman10-i.html",
    category: GameCategory.RETRO,
    rating: 4.7,
    plays: "5.2M"
  },
  {
    id: "4",
    title: "Z-Type",
    description: "Defend your base by typing words. Type faster to destroy incoming ships.",
    thumbnail: "https://images.unsplash.com/photo-1550439062-609e1531270e?w=800&q=80",
    url: "https://zty.pe/",
    category: GameCategory.ARCADE,
    rating: 4.9,
    plays: "2.1M"
  },
  {
    id: "5",
    title: "Space Invaders",
    description: "Battle endless waves of pixelated aliens in this timeless shooter.",
    thumbnail: "https://images.unsplash.com/photo-1446776811953-b23d57bd21aa?w=800&q=80",
    url: "https://freeinvaders.org/",
    category: GameCategory.RETRO,
    rating: 4.5,
    plays: "1.8M"
  },
  {
    id: "6",
    title: "Doodle Jump",
    description: "Bounce your way to the stars. Don't fall, and watch out for monsters!",
    thumbnail: "https://images.unsplash.com/photo-1612287230202-1ff1d85d1bdf?w=800&q=80",
    url: "https://doodle-jump.io/",
    category: GameCategory.ACTION,
    rating: 4.6,
    plays: "3.4M"
  },
  {
    id: "7",
    title: "Lichess",
    description: "Play chess against the world. Open source and free for everyone.",
    thumbnail: "https://images.unsplash.com/photo-1529699211952-734e80c4d42b?w=800&q=80",
    url: "https://lichess.org/training/frame",
    category: GameCategory.STRATEGY,
    rating: 4.4,
    plays: "1.2M"
  }
];
