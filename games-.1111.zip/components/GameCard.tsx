
import React from 'react';
import { Game } from '../types';
import { Play, Star, Users } from 'lucide-react';

interface GameCardProps {
  game: Game;
  onSelect: (game: Game) => void;
}

const GameCard: React.FC<GameCardProps> = ({ game, onSelect }) => {
  return (
    <div 
      onClick={() => onSelect(game)}
      className="group relative bg-slate-900/30 rounded-2xl overflow-hidden border border-slate-800/60 hover:border-indigo-500/50 transition-all duration-500 cursor-pointer hover:-translate-y-1.5 shadow-xl hover:shadow-indigo-500/10"
    >
      {/* Thumbnail */}
      <div className="relative aspect-[16/10] overflow-hidden">
        <img 
          src={game.thumbnail} 
          alt={game.title}
          loading="lazy"
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 ease-out"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#020617] via-transparent to-transparent opacity-80 group-hover:opacity-60 transition-opacity" />
        
        {/* Play Button Overlay */}
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-500">
          <div className="bg-indigo-600 p-5 rounded-full shadow-[0_0_20px_rgba(79,70,229,0.5)] transform translate-y-4 group-hover:translate-y-0 transition-all duration-500 scale-90 group-hover:scale-100">
            <Play className="w-6 h-6 fill-white text-white" />
          </div>
        </div>

        {/* Category Badge */}
        <div className="absolute top-4 left-4 px-2.5 py-1 bg-black/40 backdrop-blur-md rounded-lg text-[10px] font-black uppercase tracking-widest text-indigo-300 border border-white/10">
          {game.category}
        </div>
      </div>

      {/* Info */}
      <div className="p-5">
        <h3 className="text-base font-bold text-white mb-1.5 group-hover:text-indigo-400 transition-colors truncate">
          {game.title}
        </h3>
        <p className="text-slate-500 text-xs line-clamp-2 mb-4 leading-relaxed font-medium">
          {game.description}
        </p>
        
        <div className="flex items-center justify-between pt-4 border-t border-slate-800/40">
          <div className="flex items-center gap-1.5 text-yellow-500/90">
            <Star className="w-3.5 h-3.5 fill-current" />
            <span className="text-[10px] font-black tracking-tight">{game.rating}</span>
          </div>
          <div className="flex items-center gap-1.5 text-slate-500">
            <Users className="w-3.5 h-3.5" />
            <span className="text-[10px] font-bold tracking-tight">{game.plays}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default GameCard;
