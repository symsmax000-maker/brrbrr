
import React from 'react';
import { Game } from '../types';
import { X, Maximize2, RotateCcw, ThumbsUp } from 'lucide-react';

interface GameRoomProps {
  game: Game;
  onClose: () => void;
}

const GameRoom: React.FC<GameRoomProps> = ({ game, onClose }) => {
  const [isFullscreen, setIsFullscreen] = React.useState(false);

  const toggleFullscreen = () => {
    const frame = document.getElementById('game-frame');
    if (frame?.requestFullscreen) {
      frame.requestFullscreen();
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950 flex flex-col">
      {/* Game Header */}
      <div className="h-16 bg-slate-900 border-b border-slate-800 flex items-center justify-between px-6 shrink-0">
        <div className="flex items-center gap-4">
          <button 
            onClick={onClose}
            className="p-2 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
          <div>
            <h1 className="text-xl font-orbitron font-bold text-white leading-tight">
              {game.title}
            </h1>
            <p className="text-xs text-indigo-400 uppercase tracking-widest font-bold">
              {game.category}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button className="flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-sm font-bold transition-all shadow-lg shadow-indigo-500/20">
            <ThumbsUp className="w-4 h-4" />
            Like
          </button>
          <div className="h-8 w-[1px] bg-slate-800 mx-2" />
          <button 
            onClick={() => window.location.reload()}
            className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
          >
            <RotateCcw className="w-5 h-5" />
          </button>
          <button 
            onClick={toggleFullscreen}
            className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
          >
            <Maximize2 className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Frame Container */}
      <div className="flex-1 bg-black relative flex items-center justify-center overflow-hidden">
        <iframe 
          id="game-frame"
          src={game.url}
          className="w-full h-full border-none"
          title={game.title}
          allowFullScreen
          allow="autoplay; fullscreen; keyboard"
        />
        
        {/* Sidebar Info (Hidden on small screens) */}
        <div className="hidden lg:block absolute right-8 top-8 w-64 bg-slate-900/80 backdrop-blur-md border border-slate-800 p-6 rounded-2xl">
          <h2 className="text-lg font-bold text-white mb-2">How to Play</h2>
          <p className="text-sm text-slate-400 leading-relaxed mb-6">
            Use your arrow keys or mouse to interact with the game. Fullscreen mode is recommended for the best experience.
          </p>
          <div className="space-y-4">
            <div className="flex justify-between text-xs">
              <span className="text-slate-500">Rating</span>
              <span className="text-yellow-500 font-bold">⭐ {game.rating}</span>
            </div>
            <div className="flex justify-between text-xs">
              <span className="text-slate-500">Global Plays</span>
              <span className="text-white font-bold">{game.plays}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default GameRoom;
