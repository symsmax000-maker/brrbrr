
import React, { useState, useMemo } from 'react';
import { Search, Gamepad2, Flame, Trophy, Menu, LayoutGrid, Clock, ChevronLeft } from 'lucide-react';
import { GAMES_DATA } from './games';
import { Game, GameCategory } from './types';
import GameCard from './components/GameCard';
import GameRoom from './components/GameRoom';

const App: React.FC = () => {
  const [selectedGame, setSelectedGame] = useState<Game | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<GameCategory>(GameCategory.ALL);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  const filteredGames = useMemo(() => {
    return GAMES_DATA.filter(game => {
      const matchesSearch = game.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          game.description.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = activeCategory === GameCategory.ALL || game.category === activeCategory;
      return matchesSearch && matchesCategory;
    });
  }, [searchQuery, activeCategory]);

  const toggleSidebar = () => setIsSidebarOpen(prev => !prev);

  const categories = Object.values(GameCategory);

  return (
    <div className="min-h-screen bg-[#020617] flex text-slate-50 font-sans selection:bg-indigo-500/30">
      {/* Navigation Sidebar */}
      <aside 
        className={`${
          isSidebarOpen ? 'w-64' : 'w-20'
        } bg-slate-900/40 border-r border-slate-800/60 transition-all duration-300 hidden md:flex flex-col sticky top-0 h-screen z-40 backdrop-blur-xl`}
      >
        <div className="p-6 flex items-center gap-3">
          <div className="bg-gradient-to-br from-indigo-500 to-purple-600 p-2 rounded-xl shrink-0 shadow-lg shadow-indigo-500/20">
            <Gamepad2 className="text-white w-6 h-6" />
          </div>
          {isSidebarOpen && (
            <span className="font-orbitron font-bold text-xl tracking-tighter text-white truncate">
              NOVA<span className="text-indigo-500">ARCADE</span>
            </span>
          )}
        </div>

        <nav className="flex-1 px-4 space-y-2 mt-4">
          <button 
            onClick={() => setActiveCategory(GameCategory.ALL)}
            className={`w-full flex items-center gap-3 px-3 py-3 rounded-xl transition-all ${
              activeCategory === GameCategory.ALL && !searchQuery
              ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30' 
              : 'text-slate-400 hover:bg-slate-800 hover:text-white'
            }`}
          >
            <LayoutGrid className="w-5 h-5 shrink-0" />
            {isSidebarOpen && <span className="font-semibold text-sm">Library</span>}
          </button>
          
          <button className="w-full flex items-center gap-3 px-3 py-3 rounded-xl text-slate-400 hover:bg-slate-800 hover:text-white transition-all group">
            <Flame className="w-5 h-5 shrink-0 group-hover:text-orange-500 transition-colors" />
            {isSidebarOpen && <span className="font-semibold text-sm">Trending</span>}
          </button>
          
          <button className="w-full flex items-center gap-3 px-3 py-3 rounded-xl text-slate-400 hover:bg-slate-800 hover:text-white transition-all group">
            <Trophy className="w-5 h-5 shrink-0 group-hover:text-yellow-500 transition-colors" />
            {isSidebarOpen && <span className="font-semibold text-sm">Challenges</span>}
          </button>
          
          <div className="pt-8 pb-4">
            {isSidebarOpen && <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest px-3 mb-4">Genres</p>}
            <div className="space-y-1">
              {categories.filter(c => c !== GameCategory.ALL).map((category) => (
                <button
                  key={category}
                  onClick={() => {
                    setActiveCategory(category);
                    setSearchQuery('');
                  }}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm transition-all group ${
                    activeCategory === category
                    ? 'bg-indigo-500/10 text-indigo-400 font-bold'
                    : 'text-slate-500 hover:text-slate-300 hover:bg-slate-800/50'
                  }`}
                >
                  <div className={`w-1.5 h-1.5 rounded-full transition-all duration-300 ${activeCategory === category ? 'bg-indigo-400 scale-125 shadow-[0_0_8px_rgba(129,140,248,0.8)]' : 'bg-slate-700 group-hover:bg-slate-500'}`} />
                  {isSidebarOpen && <span>{category}</span>}
                </button>
              ))}
            </div>
          </div>
        </nav>

        <div className="p-4 border-t border-slate-800/60">
          <button 
            onClick={toggleSidebar}
            className="w-full flex items-center gap-3 px-3 py-3 rounded-xl text-slate-500 hover:bg-slate-800 hover:text-slate-300 transition-all"
          >
            {isSidebarOpen ? <ChevronLeft className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            {isSidebarOpen && <span className="text-sm font-medium">Collapse Menu</span>}
          </button>
        </div>
      </aside>

      {/* Main Experience */}
      <main className="flex-1 flex flex-col min-w-0 overflow-x-hidden">
        {/* Global Header */}
        <header className="h-20 bg-[#020617]/80 backdrop-blur-md sticky top-0 z-30 px-6 flex items-center justify-between border-b border-slate-800/40">
          <div className="flex-1 max-w-2xl relative group">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 w-4 h-4 group-focus-within:text-indigo-500 transition-colors" />
            <input 
              type="text" 
              placeholder="Search games, genres, or keywords..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-900/40 border border-slate-800/60 rounded-2xl py-3 pl-11 pr-4 text-white focus:outline-none focus:ring-2 focus:ring-indigo-600/30 transition-all placeholder:text-slate-600 text-sm"
            />
          </div>
          
          <div className="flex items-center gap-4 ml-6">
            <div className="hidden sm:flex items-center gap-2 bg-slate-900/60 px-4 py-2 rounded-xl border border-slate-800/60 shadow-inner">
              <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-[10px] font-bold text-white uppercase tracking-tighter">Status: Online</span>
            </div>
          </div>
        </header>

        {/* Page Content */}
        <div className="p-6 md:p-8">
          {/* Featured Game Spotlight */}
          {activeCategory === GameCategory.ALL && !searchQuery && (
            <div className="relative rounded-[2rem] overflow-hidden bg-gradient-to-br from-indigo-900/40 via-slate-900 to-indigo-950/40 p-8 md:p-14 mb-12 shadow-2xl border border-white/5 group">
              <div className="relative z-10 max-w-xl">
                <div className="inline-flex items-center gap-2 px-3 py-1 bg-indigo-500/20 text-indigo-300 text-[10px] font-bold uppercase tracking-widest rounded-full mb-6 border border-indigo-500/20">
                  <Clock className="w-3 h-3" /> New Release Added
                </div>
                <h2 className="text-4xl md:text-6xl font-orbitron font-bold text-white mb-6 leading-[1.1] tracking-tight">
                  UNBLOCKED <br/><span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-purple-400">ARCADE</span>
                </h2>
                <p className="text-slate-400 text-lg mb-10 leading-relaxed max-w-md">
                  Experience fast, restriction-free access to high-performance web games curated for quality.
                </p>
                <div className="flex flex-wrap gap-4">
                  <button 
                    onClick={() => GAMES_DATA.length > 0 && setSelectedGame(GAMES_DATA[0])}
                    className="px-8 py-4 bg-indigo-600 text-white rounded-2xl font-bold text-base hover:bg-indigo-500 transition-all shadow-xl shadow-indigo-600/20 flex items-center gap-3 group/btn"
                  >
                    Play Featured Game
                    <Gamepad2 className="w-5 h-5 group-hover/btn:rotate-12 transition-transform" />
                  </button>
                </div>
              </div>
              <div className="absolute right-0 bottom-0 top-0 w-1/2 opacity-5 pointer-events-none overflow-hidden hidden lg:block">
                 <Gamepad2 className="w-[500px] h-[500px] absolute -right-20 -bottom-20 rotate-12 text-indigo-500" />
              </div>
            </div>
          )}

          {/* Library Header */}
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-3">
              <div className="w-1 h-8 bg-indigo-600 rounded-full" />
              <h3 className="text-2xl font-orbitron font-bold text-white tracking-tight">
                {searchQuery ? 'SEARCH RESULTS' : `${activeCategory.toUpperCase()} GAMES`}
              </h3>
            </div>
            <p className="text-slate-500 text-xs font-bold uppercase tracking-widest bg-slate-900/80 px-4 py-2 rounded-lg border border-slate-800">
              {filteredGames.length} Available
            </p>
          </div>

          {/* Game Library Grid */}
          {filteredGames.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 gap-6">
              {filteredGames.map((game) => (
                <GameCard 
                  key={game.id} 
                  game={game} 
                  onSelect={setSelectedGame} 
                />
              ))}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-32 text-center bg-slate-900/20 rounded-[2rem] border border-dashed border-slate-800">
              <div className="bg-slate-900 p-8 rounded-full mb-6 border border-slate-800 shadow-xl">
                <Search className="w-12 h-12 text-slate-700" />
              </div>
              <h4 className="text-2xl font-bold text-white mb-2">No results found</h4>
              <p className="text-slate-500 max-w-xs mx-auto">We couldn't find any games matching your request. Try broadening your search.</p>
              <button 
                onClick={() => {setSearchQuery(''); setActiveCategory(GameCategory.ALL);}}
                className="mt-8 px-6 py-2.5 bg-slate-800 text-white font-bold rounded-xl hover:bg-slate-700 transition-all border border-slate-700"
              >
                Clear Filters
              </button>
            </div>
          )}
        </div>

        {/* Global Footer */}
        <footer className="mt-auto p-10 border-t border-slate-800/40 bg-[#020617]">
          <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-8 opacity-40 text-[10px] font-bold uppercase tracking-widest text-slate-500">
            <div className="flex items-center gap-10">
              <span className="text-indigo-400">© 2025 NOVARCADE PORTAL</span>
              <a href="#" className="hover:text-white transition-colors">Privacy</a>
              <a href="#" className="hover:text-white transition-colors">Terms</a>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
              <span>CDN: GLOBAL-EDGE-1</span>
            </div>
          </div>
        </footer>
      </main>

      {/* Immersive Game Room Overlay */}
      {selectedGame && (
        <GameRoom 
          game={selectedGame} 
          onClose={() => setSelectedGame(null)} 
        />
      )}
    </div>
  );
};

export default App;
