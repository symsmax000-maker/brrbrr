import React, { useState, useMemo } from 'react';
import { Search, Gamepad2, Flame, Trophy, Menu, LayoutGrid, Clock, ChevronLeft, Zap, Sparkles } from 'lucide-react';
import { GAMES_DATA } from './games.ts';
import { Game, GameCategory } from './types.ts';
import GameCard from './components/GameCard.tsx';
import GameRoom from './components/GameRoom.tsx';

const App: React.FC = () => {
  const [selectedGame, setSelectedGame] = useState<Game | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<GameCategory>(GameCategory.ALL);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  const filteredGames = useMemo(() => {
    return GAMES_DATA.filter(game => {
      const matchesSearch = game.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          game.description.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = activeCategory === GameCategory.ALL || game.category === activeCategory;
      return matchesSearch && matchesCategory;
    });
  }, [searchQuery, activeCategory]);

  const toggleSidebar = () => setIsSidebarOpen(prev => !prev);
  const categories = Object.values(GameCategory);

  const handleSurpriseMe = () => {
    const randomIndex = Math.floor(Math.random() * GAMES_DATA.length);
    setSelectedGame(GAMES_DATA[randomIndex]);
  };

  return (
    <div className="min-h-screen bg-[#020617] flex text-slate-50 font-sans">
      {/* Sidebar Navigation */}
      <aside 
        className={`${
          isSidebarOpen ? 'w-64' : 'w-20'
        } bg-slate-900/30 border-r border-slate-800/40 transition-all duration-300 hidden md:flex flex-col sticky top-0 h-screen z-40 backdrop-blur-2xl`}
      >
        <div className="p-6 flex items-center gap-3">
          <div className="bg-gradient-to-br from-indigo-500 to-purple-600 p-2 rounded-xl shrink-0 shadow-lg shadow-indigo-500/20">
            <Gamepad2 className="text-white w-6 h-6" />
          </div>
          {isSidebarOpen && (
            <span className="font-orbitron font-bold text-lg tracking-tighter text-white truncate">
              NOVA<span className="text-indigo-500">ARCADE</span>
            </span>
          )}
        </div>

        <nav className="flex-1 px-4 space-y-2 mt-4 overflow-y-auto custom-scrollbar">
          <button 
            onClick={() => {setActiveCategory(GameCategory.ALL); setSearchQuery('');}}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
              activeCategory === GameCategory.ALL && !searchQuery
              ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30' 
              : 'text-slate-400 hover:bg-slate-800/50 hover:text-white'
            }`}
          >
            <LayoutGrid className="w-5 h-5 shrink-0" />
            {isSidebarOpen && <span className="font-semibold text-sm">Library</span>}
          </button>
          
          <button className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-slate-400 hover:bg-slate-800/50 hover:text-white transition-all group">
            <Flame className="w-5 h-5 shrink-0 group-hover:text-orange-500" />
            {isSidebarOpen && <span className="font-semibold text-sm">Trending</span>}
          </button>
          
          <button className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-slate-400 hover:bg-slate-800/50 hover:text-white transition-all group">
            <Zap className="w-5 h-5 shrink-0 group-hover:text-yellow-400" />
            {isSidebarOpen && <span className="font-semibold text-sm">Fast Access</span>}
          </button>

          <div className="pt-8 pb-4">
            {isSidebarOpen && <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest px-4 mb-4">Categories</p>}
            <div className="space-y-1">
              {categories.filter(c => c !== GameCategory.ALL).map((category) => (
                <button
                  key={category}
                  onClick={() => {
                    setActiveCategory(category);
                    setSearchQuery('');
                  }}
                  className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm transition-all group ${
                    activeCategory === category
                    ? 'bg-indigo-500/10 text-indigo-400 font-bold'
                    : 'text-slate-500 hover:text-slate-300 hover:bg-slate-800/40'
                  }`}
                >
                  <div className={`w-1.5 h-1.5 rounded-full transition-all duration-300 ${activeCategory === category ? 'bg-indigo-400 scale-125 shadow-[0_0_8px_rgba(129,140,248,0.8)]' : 'bg-slate-700'}`} />
                  {isSidebarOpen && <span>{category}</span>}
                </button>
              ))}
            </div>
          </div>
        </nav>

        <div className="p-4 border-t border-slate-800/40">
          <button 
            onClick={toggleSidebar}
            className="w-full flex items-center gap-3 px-3 py-3 rounded-xl text-slate-500 hover:bg-slate-800 hover:text-slate-300 transition-all"
          >
            {isSidebarOpen ? <ChevronLeft className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            {isSidebarOpen && <span className="text-sm font-medium">Collapse</span>}
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col min-w-0 h-screen overflow-y-auto custom-scrollbar">
        <header className="h-20 bg-slate-950/80 backdrop-blur-md sticky top-0 z-30 px-6 flex items-center justify-between border-b border-slate-800/40 shrink-0">
          <div className="flex-1 max-w-2xl relative group">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 w-4 h-4 group-focus-within:text-indigo-400 transition-colors" />
            <input 
              type="text" 
              placeholder="Search for your favorite games..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-900/40 border border-slate-800/60 rounded-2xl py-3 pl-11 pr-4 text-white focus:outline-none focus:ring-2 focus:ring-indigo-600/30 transition-all placeholder:text-slate-600 text-sm"
            />
          </div>
          
          <div className="flex items-center gap-4 ml-6 hidden sm:flex">
             <div className="px-4 py-2 bg-slate-900/60 rounded-xl border border-slate-800/60 flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                <span className="text-[10px] font-bold text-white uppercase tracking-tighter">Proxy Active</span>
             </div>
          </div>
        </header>

        <div className="p-6 md:p-8 lg:p-12">
          {/* Spotlight Hero Section */}
          {activeCategory === GameCategory.ALL && !searchQuery && (
            <div className="relative rounded-[2.5rem] overflow-hidden bg-gradient-to-br from-indigo-900/40 via-slate-900 to-indigo-950/40 p-10 md:p-16 mb-16 shadow-3xl border border-white/5 group">
              <div className="relative z-10 max-w-2xl">
                <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-indigo-500/20 text-indigo-300 text-[10px] font-black uppercase tracking-[0.2em] rounded-full mb-8 border border-indigo-500/30">
                  <Clock className="w-3 h-3" /> RESTRICTION FREE ACCESS
                </div>
                <h2 className="text-5xl md:text-7xl font-orbitron font-bold text-white mb-8 leading-[1.05] tracking-tight">
                  PLAY <br/>
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 via-purple-400 to-indigo-400">
                    ANYWHERE.
                  </span>
                </h2>
                <p className="text-slate-400 text-lg md:text-xl mb-12 leading-relaxed max-w-lg">
                  Access a curated vault of high-performance web games designed to run smoothly on any network.
                </p>
                <div className="flex flex-wrap gap-4">
                  <button 
                    onClick={() => GAMES_DATA.length > 0 && setSelectedGame(GAMES_DATA[0])}
                    className="px-10 py-5 bg-indigo-600 text-white rounded-2xl font-bold text-lg hover:bg-indigo-500 transition-all shadow-2xl shadow-indigo-600/30 flex items-center gap-3 active:scale-95"
                  >
                    Play Feature
                    <Gamepad2 className="w-6 h-6" />
                  </button>
                  <button 
                    onClick={handleSurpriseMe}
                    className="px-10 py-5 bg-slate-800/80 text-white rounded-2xl font-bold text-lg hover:bg-slate-700 transition-all border border-slate-700 flex items-center gap-3 active:scale-95"
                  >
                    Surprise Me
                    <Sparkles className="w-6 h-6 text-yellow-400" />
                  </button>
                </div>
              </div>
              <div className="absolute right-0 bottom-0 top-0 w-2/3 opacity-[0.03] pointer-events-none overflow-hidden hidden lg:block">
                 <Gamepad2 className="w-[800px] h-[800px] absolute -right-40 -bottom-40 rotate-12 text-white" />
              </div>
            </div>
          )}

          {/* Library Heading */}
          <div className="flex items-center justify-between mb-10">
            <div className="flex items-center gap-4">
              <div className="w-1.5 h-10 bg-indigo-600 rounded-full" />
              <h3 className="text-3xl font-orbitron font-bold text-white tracking-tight">
                {searchQuery ? 'SEARCH RESULTS' : `${activeCategory.toUpperCase()} COLLECTION`}
              </h3>
            </div>
            <div className="text-slate-500 text-[10px] font-bold uppercase tracking-widest bg-slate-900/60 px-5 py-2.5 rounded-full border border-slate-800">
              {filteredGames.length} Titles Found
            </div>
          </div>

          {/* Grid View */}
          {filteredGames.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 gap-8">
              {filteredGames.map((game) => (
                <GameCard 
                  key={game.id} 
                  game={game} 
                  onSelect={setSelectedGame} 
                />
              ))}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-40 text-center bg-slate-900/20 rounded-[3rem] border-2 border-dashed border-slate-800/50">
              <div className="bg-slate-900 p-10 rounded-full mb-8 border border-slate-800 shadow-2xl">
                <Search className="w-16 h-16 text-slate-700" />
              </div>
              <h4 className="text-3xl font-bold text-white mb-4">No matches found</h4>
              <p className="text-slate-500 max-w-sm mx-auto text-lg leading-relaxed">Try adjusting your search or filters to find what you're looking for.</p>
              <button 
                onClick={() => {setSearchQuery(''); setActiveCategory(GameCategory.ALL);}}
                className="mt-10 px-8 py-3 bg-slate-800 text-white font-bold rounded-2xl hover:bg-slate-700 transition-all border border-slate-700"
              >
                Clear Search
              </button>
            </div>
          )}
        </div>

        {/* Dynamic Footer */}
        <footer className="mt-auto p-12 border-t border-slate-800/40 bg-slate-950 shrink-0">
          <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-10 opacity-40 text-[10px] font-bold uppercase tracking-[0.3em] text-slate-500">
            <div className="flex items-center gap-12">
              <span className="text-indigo-400">© 2025 NOVARCADE PORTAL</span>
              <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
              <a href="#" className="hover:text-white transition-colors">Safety Guide</a>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
              <span>Edge Server Status: Nominal</span>
            </div>
          </div>
        </footer>
      </main>

      {/* Game Overlay */}
      {selectedGame && (
        <GameRoom 
          game={selectedGame} 
          onClose={() => setSelectedGame(null)} 
        />
      )}
    </div>
  );
};

export default App;