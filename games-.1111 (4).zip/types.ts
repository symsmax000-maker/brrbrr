
export enum GameCategory {
  ALL = 'All',
  ACTION = 'Action',
  PUZZLE = 'Puzzle',
  ARCADE = 'Arcade',
  SPORTS = 'Sports',
  RETRO = 'Retro',
  STRATEGY = 'Strategy'
}

export interface Game {
  id: string;
  title: string;
  description: string;
  thumbnail: string;
  url: string;
  category: GameCategory;
  rating: number;
  plays: string;
}
