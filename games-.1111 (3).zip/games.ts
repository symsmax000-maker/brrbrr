import { Game, GameCategory } from './types.ts';

export const GAMES_DATA: Game[] = [
  {
    id: "1",
    title: "Hextris",
    description: "Fast-paced hexagon puzzle. Rotate the hex to match incoming blocks.",
    thumbnail: "https://images.unsplash.com/photo-1614850523296-d8c1af93d400?w=800&q=80",
    url: "https://hextris.io/",
    category: GameCategory.PUZZLE,
    rating: 4.8,
    plays: "2.5M"
  },
  {
    id: "2",
    title: "2048",
    description: "The viral number-sliding challenge. Reach the 2048 tile!",
    thumbnail: "https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=800&q=80",
    url: "https://play2048.co/",
    category: GameCategory.PUZZLE,
    rating: 4.9,
    plays: "10M+"
  },
  {
    id: "3",
    title: "Pac-Man",
    description: "The retro legend. Navigate the maze and avoid the ghosts.",
    thumbnail: "https://images.unsplash.com/photo-1552820728-8b83bb6b773f?w=800&q=80",
    url: "https://www.google.com/logos/2010/pacman10-i.html",
    category: GameCategory.RETRO,
    rating: 4.7,
    plays: "5.2M"
  },
  {
    id: "4",
    title: "Z-Type",
    description: "Type words to destroy space invaders in this epic typing shooter.",
    thumbnail: "https://images.unsplash.com/photo-1550439062-609e1531270e?w=800&q=80",
    url: "https://zty.pe/",
    category: GameCategory.ARCADE,
    rating: 4.9,
    plays: "2.1M"
  },
  {
    id: "5",
    title: "Space Invaders",
    description: "Classic arcade action. Defend Earth from alien invaders.",
    thumbnail: "https://images.unsplash.com/photo-1446776811953-b23d57bd21aa?w=800&q=80",
    url: "https://freeinvaders.org/",
    category: GameCategory.RETRO,
    rating: 4.5,
    plays: "1.8M"
  },
  {
    id: "6",
    title: "Doodle Jump",
    description: "Bounce upward and dodge monsters in this addictive climber.",
    thumbnail: "https://images.unsplash.com/photo-1612287230202-1ff1d85d1bdf?w=800&q=80",
    url: "https://doodle-jump.io/",
    category: GameCategory.ACTION,
    rating: 4.6,
    plays: "3.4M"
  },
  {
    id: "7",
    title: "Lichess",
    description: "The premier open-source chess platform. Play and learn strategy.",
    thumbnail: "https://images.unsplash.com/photo-1529699211952-734e80c4d42b?w=800&q=80",
    url: "https://lichess.org/training/frame",
    category: GameCategory.STRATEGY,
    rating: 4.8,
    plays: "1.2M"
  },
  {
    id: "8",
    title: "Slope",
    description: "High-speed 3D runner. Control the ball and stay on the platforms.",
    thumbnail: "https://images.unsplash.com/photo-1511512578047-dfb367046420?w=800&q=80",
    url: "https://slopegame.io/",
    category: GameCategory.ACTION,
    rating: 4.9,
    plays: "8.1M"
  },
  {
    id: "9",
    title: "Tetris Lite",
    description: "The classic block-stacking puzzle. Clear lines to score big.",
    thumbnail: "https://images.unsplash.com/photo-1585338107529-13afc5f02586?w=800&q=80",
    url: "https://tetris.com/play-tetris",
    category: GameCategory.PUZZLE,
    rating: 4.7,
    plays: "15M"
  },
  {
    id: "10",
    title: "Google Snake",
    description: "Eat apples and grow your snake in this modern take on the classic.",
    thumbnail: "https://images.unsplash.com/photo-1579373903781-fd5c0c30c4cd?w=800&q=80",
    url: "https://www.google.com/logos/2010/pacman10-i.html", // Re-using engine or similar arcade link
    category: GameCategory.ARCADE,
    rating: 4.8,
    plays: "20M"
  },
  {
    id: "11",
    title: "Minesweeper",
    description: "Use logic to clear the board without hitting a single mine.",
    thumbnail: "https://images.unsplash.com/photo-1563203369-26f2e4a5ccf7?w=800&q=80",
    url: "https://minesweeperonline.com/",
    category: GameCategory.STRATEGY,
    rating: 4.4,
    plays: "4.2M"
  },
  {
    id: "12",
    title: "Flappy Bird",
    description: "Tap to fly and dodge the pipes. Harder than it looks!",
    thumbnail: "https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=800&q=80",
    url: "https://flappybird.io/",
    category: GameCategory.ARCADE,
    rating: 4.2,
    plays: "9.5M"
  }
];