import { Game, GameCategory } from './types.ts';

export const GAMES_DATA: Game[] = [];